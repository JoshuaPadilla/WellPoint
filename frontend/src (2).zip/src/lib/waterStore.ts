import { useSyncExternalStore } from 'react'

// Stand-in for the backend: everything lives in this module and is saved to localStorage.
// Swap the action functions for API calls later and keep the same names.

export type Role = 'lgu' | 'official' | 'drrm' | 'citizen'
export type AssetKind = 'pump' | 'reservoir' | 'station'
export type Status = 'ok' | 'empty'
export type Issue = 'empty' | 'low' | 'dirty'
export type Asset = { id: string; kind: AssetKind; name: string; lng: number; lat: number; status: Status }
export type Report = { id: string; assetId: string; issue: Issue; note: string; at: number }

export const ROLES: { id: Role; label: string; hint: string }[] = [
  { id: 'citizen', label: 'Citizen', hint: 'Select a water pump on the map to report a problem.' },
  { id: 'official', label: 'Barangay official', hint: 'Select a water pump to read its reports and mark it empty.' },
  { id: 'lgu', label: 'LGU', hint: 'Drag pumps and reservoirs onto the map. Drag a marker to move it.' },
  { id: 'drrm', label: 'DRRM', hint: 'Drag filling stations onto the map. Drag a marker to move it.' },
]
export const KINDS: Record<AssetKind, string> = { pump: 'Water pump', reservoir: 'Reservoir', station: 'Filling station' }
export const ISSUES: Record<Issue, string> = { empty: 'No water coming out', low: 'Low flow', dirty: 'Dirty water' }
export const CAN_PLACE: Record<Role, AssetKind[]> = {
  lgu: ['pump', 'reservoir'],
  drrm: ['station'],
  official: [],
  citizen: [],
}

type State = { role: Role; assets: Asset[]; reports: Report[] }

// Sample positions only. Replace with the real pumps once the LGU adds them.
const seed: Asset[] = [
  { id: 'a1', kind: 'pump', name: 'Poblacion pump', lng: 124.8838, lat: 11.7762, status: 'ok' },
  { id: 'a2', kind: 'pump', name: 'Muñoz pump', lng: 124.8826, lat: 11.7842, status: 'ok' },
  { id: 'a3', kind: 'pump', name: 'San Roque pump', lng: 124.8345, lat: 11.8075, status: 'ok' },
  { id: 'a4', kind: 'reservoir', name: 'Maulong reservoir', lng: 124.878, lat: 11.796, status: 'ok' },
  { id: 'a5', kind: 'station', name: 'City hall filling station', lng: 124.8855, lat: 11.774, status: 'ok' },
]

const KEY = 'wellpoint.demo.v1'

function load(): State {
  try {
    const raw = typeof localStorage === 'undefined' ? null : localStorage.getItem(KEY)
    if (raw) return JSON.parse(raw) as State
  } catch {
    /* fall through to the seed */
  }
  return { role: 'citizen', assets: seed, reports: [] }
}

let state = load()
const listeners = new Set<() => void>()

function set(next: State) {
  state = next
  try {
    localStorage.setItem(KEY, JSON.stringify(next))
  } catch {
    /* storage full or blocked: keep working in memory */
  }
  listeners.forEach((l) => l())
}

export function useWaterStore() {
  return useSyncExternalStore(
    (cb) => {
      listeners.add(cb)
      return () => listeners.delete(cb)
    },
    () => state,
    () => state,
  )
}

export const setRole = (role: Role) => set({ ...state, role })

export function addAsset(kind: AssetKind, lng: number, lat: number) {
  if (!CAN_PLACE[state.role].includes(kind)) return
  const n = state.assets.filter((a) => a.kind === kind).length + 1
  const asset: Asset = { id: crypto.randomUUID(), kind, name: `${KINDS[kind]} ${n}`, lng, lat, status: 'ok' }
  set({ ...state, assets: [...state.assets, asset] })
}

export const moveAsset = (id: string, lng: number, lat: number) =>
  set({ ...state, assets: state.assets.map((a) => (a.id === id ? { ...a, lng, lat } : a)) })

export const removeAsset = (id: string) =>
  set({
    ...state,
    assets: state.assets.filter((a) => a.id !== id),
    reports: state.reports.filter((r) => r.assetId !== id),
  })

export const fileReport = (assetId: string, issue: Issue, note: string) =>
  set({ ...state, reports: [...state.reports, { id: crypto.randomUUID(), assetId, issue, note, at: Date.now() }] })

// Marking a pump working also clears its open reports.
export const setStatus = (assetId: string, status: Status) =>
  set({
    ...state,
    assets: state.assets.map((a) => (a.id === assetId ? { ...a, status } : a)),
    reports: status === 'ok' ? state.reports.filter((r) => r.assetId !== assetId) : state.reports,
  })